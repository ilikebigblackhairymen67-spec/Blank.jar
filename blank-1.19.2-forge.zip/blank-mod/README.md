# (blank)™ — Minecraft Forge Mod Template
### Forge 43.5.2 · Minecraft 1.19.2 · Java 17

A zero-content prototype mod. Everything you need to start building is already wired up — no blocks, no items, no noise. Just open it in your IDE and go.

---

## Prerequisites

| Tool | Version |
|------|---------|
| JDK  | 17 (exact — not 18+) |
| Gradle | Provided via `gradlew` wrapper |
| IDE | IntelliJ IDEA or Eclipse |

> **Note:** You do **not** need to run the Forge installer. The MDK handles everything through Gradle.

---

## First-time setup

```bash
# 1. Generate IDE run configurations
./gradlew genIntellijRuns   # IntelliJ IDEA
./gradlew genEclipseRuns    # Eclipse

# 2. Refresh Gradle in your IDE, then run the 'runClient' config to launch the game
```

On first run Gradle will download Minecraft, Forge, and all mappings (~2–5 GB). This is a one-time operation cached in `~/.gradle`.

---

## Project layout

```
blank/
├── build.gradle              # Build config — add dependencies here
├── gradle.properties         # mod_id, mod_version, mod_authors, …
├── settings.gradle           # Project name
├── src/
│   └── main/
│       ├── java/com/blank/blank/
│       │   ├── BlankMod.java     ← Main entry point
│       │   └── BlankConfig.java  ← Forge config (TOML)
│       └── resources/
│           ├── blank.png         ← Mod logo
│           ├── pack.mcmeta
│           └── META-INF/
│               └── mods.toml     ← Mod metadata
└── run/                      ← Created on first runClient
```

---

## Customising the mod ID

1. Edit **`gradle.properties`** — change `mod_id`, `mod_name`, `mod_authors`, `mod_group_id`, `mod_version`
2. Rename the Java package `com.blank.blank` → `com.yourname.yourmod`
3. Update the `MODID` constant in `BlankMod.java`
4. Rename `BlankMod` and `BlankConfig` to match your mod name

---

## Adding content

All registry stubs are pre-written in `BlankMod.java` as comments. Uncomment the ones you need:

```java
// Blocks
public static final DeferredRegister<Block> BLOCKS =
        DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);

// Items
public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
```

Then register each object inside the constructor and call `BLOCKS.register(modEventBus)`.

---

## Useful Gradle tasks

| Task | Description |
|------|-------------|
| `./gradlew runClient` | Launch Minecraft client in dev |
| `./gradlew runServer` | Launch dedicated server in dev |
| `./gradlew runData`   | Run data generators |
| `./gradlew build`     | Build the final `.jar` → `build/libs/` |

---

## Resources

- [MinecraftForge docs](https://docs.minecraftforge.net/)
- [Forge community Discord](https://discord.gg/UvedJ9m)
- [MCModding wiki](https://mcmodding.info/)
- [Parchment mappings](https://parchmentmc.org/) (better parameter names)

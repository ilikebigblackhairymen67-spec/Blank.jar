package com.blank.blank;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * (blank) Mod Configuration
 *
 * <p>Values defined here are read from / written to {@code config/blank-common.toml}
 * automatically by Forge. Add your own config entries as static fields below.</p>
 *
 * <h2>How to add a config value</h2>
 * <pre>{@code
 * // Inside the static initializer block:
 * myBoolean = builder
 *         .comment("Description shown in the config file")
 *         .define("myBoolean", true);
 *
 * myInt = builder
 *         .comment("An integer between 0 and 100")
 *         .defineInRange("myInt", 50, 0, 100);
 *
 * myString = builder
 *         .comment("A text value")
 *         .define("myString", "default");
 * }</pre>
 *
 * <p>Then declare the matching static field:
 * {@code public static ForgeConfigSpec.BooleanValue myBoolean;}</p>
 *
 * <p>Read values at runtime with {@code BlankConfig.myBoolean.get()}.</p>
 */
public class BlankConfig {

    // -------------------------------------------------------------------------
    // Built config spec — passed to Forge in BlankMod constructor
    // -------------------------------------------------------------------------
    public static final ForgeConfigSpec SPEC;

    // -------------------------------------------------------------------------
    // Example config values (uncomment to use)
    // -------------------------------------------------------------------------
    // public static ForgeConfigSpec.BooleanValue enableFeature;
    // public static ForgeConfigSpec.IntValue someIntValue;
    // public static ForgeConfigSpec.DoubleValue someDoubleValue;
    // public static ForgeConfigSpec.ConfigValue<String> someStringValue;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.comment("(blank) Common Configuration").push("blank");

        // --- Add your config entries here ---
        //
        // enableFeature = builder
        //         .comment("Set to false to disable the example feature")
        //         .define("enableFeature", true);
        //
        // someIntValue = builder
        //         .comment("An example integer setting")
        //         .defineInRange("someIntValue", 10, 0, 100);

        builder.pop();

        SPEC = builder.build();
    }
}

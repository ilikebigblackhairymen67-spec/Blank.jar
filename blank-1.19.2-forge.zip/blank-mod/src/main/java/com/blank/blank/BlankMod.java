package com.blank.blank;

import com.mojang.logging.LogUtils;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

/*
 * Uncomment each import as you start using the registry type:
 *
 * import net.minecraft.world.item.Item;
 * import net.minecraft.world.level.block.Block;
 * import net.minecraft.world.entity.EntityType;
 * import net.minecraft.world.effect.MobEffect;
 * import net.minecraft.world.item.enchantment.Enchantment;
 * import net.minecraft.sounds.SoundEvent;
 * import net.minecraft.world.item.crafting.RecipeSerializer;
 * import net.minecraft.world.level.levelgen.feature.Feature;
 * import net.minecraftforge.registries.RegistryObject;
 */
import org.slf4j.Logger;

/**
 * (blank) — Forge 1.19.2 mod template
 *
 * <p>This is your mod's main entry point. The {@code @Mod} annotation value
 * must exactly match {@code mod_id} in gradle.properties AND the constant
 * {@link #MODID} below.</p>
 *
 * <h2>Quick-start checklist</h2>
 * <ol>
 *   <li>Set your details in <b>gradle.properties</b> (mod_id, mod_name, mod_authors, …)</li>
 *   <li>Rename this class and its package to match your mod (optional but recommended)</li>
 *   <li>Uncomment the {@link DeferredRegister} fields you need below</li>
 *   <li>Add your content in separate registry classes (e.g. {@code ModBlocks}, {@code ModItems})</li>
 *   <li>Run {@code ./gradlew genEclipseRuns} or {@code ./gradlew genIntellijRuns} to set up IDE run configs</li>
 *   <li>Run the {@code runClient} task to test in-game</li>
 * </ol>
 */
@Mod(BlankMod.MODID)
public class BlankMod {

    // -------------------------------------------------------------------------
    // Mod ID — must match mod_id in gradle.properties and in mods.toml
    // -------------------------------------------------------------------------
    public static final String MODID = "blank";

    // SLF4J logger — use LOGGER.info / LOGGER.debug / LOGGER.warn / LOGGER.error
    private static final Logger LOGGER = LogUtils.getLogger();

    // =========================================================================
    // Deferred Registers — uncomment the ones you need, then call .register()
    // inside the constructor below.
    //
    // Keep each registry in its own dedicated class for larger mods, e.g.:
    //   public class ModBlocks { public static final DeferredRegister<Block> BLOCKS = ... }
    // =========================================================================

    // Blocks
    // public static final DeferredRegister<Block> BLOCKS =
    //         DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);

    // Items  (BlockItems live here too — register them after their Block)
    // public static final DeferredRegister<Item> ITEMS =
    //         DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    // Entities
    // public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
    //         DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);

    // Mob effects (potions)
    // public static final DeferredRegister<MobEffect> MOB_EFFECTS =
    //         DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MODID);

    // Enchantments
    // public static final DeferredRegister<Enchantment> ENCHANTMENTS =
    //         DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MODID);

    // Sound events
    // public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
    //         DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);

    // Recipe serializers
    // public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
    //         DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, MODID);

    // World-gen features
    // public static final DeferredRegister<Feature<?>> FEATURES =
    //         DeferredRegister.create(ForgeRegistries.FEATURES, MODID);

    // =========================================================================
    // Constructor — called once when the mod is loaded by FML
    // =========================================================================
    public BlankMod(FMLJavaModLoadingContext context) {
        IEventBus modEventBus = context.getModEventBus();

        // Register setup listeners
        modEventBus.addListener(this::commonSetup);

        // Register your DeferredRegisters here — one line per register, e.g.:
        // BLOCKS.register(modEventBus);
        // ITEMS.register(modEventBus);
        // ENTITY_TYPES.register(modEventBus);

        // Subscribe this class to Forge's main event bus (server events, world events, …)
        MinecraftForge.EVENT_BUS.register(this);

        // Register the mod config (remove if you don't need config)
        context.registerConfig(ModConfig.Type.COMMON, BlankConfig.SPEC);

        LOGGER.info("[blank] Mod loaded — Minecraft {}", "1.19.2");
    }

    // =========================================================================
    // Common setup — runs on BOTH client and server during mod loading.
    // Safe for registering capabilities, network channels, etc.
    // =========================================================================
    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("[blank] Common setup complete");

        // enqueue work that must run on the main thread:
        // event.enqueueWork(() -> { ... });
    }

    // =========================================================================
    // Server events — annotate methods with @SubscribeEvent to receive them.
    // These fire on the Forge main event bus (registered in the constructor).
    // =========================================================================
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        LOGGER.info("[blank] Server starting");
    }

    // =========================================================================
    // Client-only events — separated into an inner class so the server JVM
    // never tries to load client-only classes (Minecraft, RenderSystem, …).
    // =========================================================================
    @Mod.EventBusSubscriber(modid = MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {

        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            LOGGER.info("[blank] Client setup complete");

            // Register screen factories, key bindings, renderers, etc. here.
            // e.g. MenuScreens.register(ModMenuTypes.MY_MENU.get(), MyScreen::new);
        }
    }
}
